public interface Playable {
    void play();
    void stop();
    void next ();
    void prev ();
}
