public interface Trackable  {
    void getCoordinates();
}
